//
//  CallSwiftClass2.swift
//  MergeableLibrary2
//
//  Created by Aleksandra Generowicz on 23/10/2023.
//

import Foundation
import StaticLibrary

public class CallSwiftClass2 {
    public static func callMethod2() {
        SwiftClassTest.somePublicMethod()
    }
}
