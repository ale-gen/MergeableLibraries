//
//  CallSwiftTest.swift
//  MergeableLibrary1
//
//  Created by Aleksandra Generowicz on 23/10/2023.
//

import Foundation
import StaticLibrary

public class CallSwiftTest {
    public static func callMethod1() {
        SwiftClassTest.somePublicMethod()
    }
}
