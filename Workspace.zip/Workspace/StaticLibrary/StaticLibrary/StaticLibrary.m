#import "StaticLibrary.h"

@implementation StaticLibrary

+ (void)operation {
    NSLog(@"StaticLibrary.operation");
}

@end
