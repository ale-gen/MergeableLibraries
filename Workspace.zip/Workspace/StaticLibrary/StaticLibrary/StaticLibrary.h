#import <Foundation/Foundation.h>

@interface StaticLibrary : NSObject

+ (void)operation;

@end
