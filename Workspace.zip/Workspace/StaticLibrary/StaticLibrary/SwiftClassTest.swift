//
//  SwiftClassTest.swift
//  StaticLibrary
//
//  Created by Aleksandra Generowicz on 23/10/2023.
//

import Foundation

public class SwiftClassTest {
    
    public static func somePublicMethod() {
        print("DHJSHKDSAD")
    }
}
