#import <Foundation/Foundation.h>

//! Project version number for DynamicFramework2.
FOUNDATION_EXPORT double DynamicFramework2VersionNumber;

//! Project version string for DynamicFramework2.
FOUNDATION_EXPORT const unsigned char DynamicFramework2VersionString[];

#import <DynamicFramework2/DF2Class1.h>
