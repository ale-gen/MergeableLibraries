#import <Foundation/Foundation.h>

//! Project version number for DynamicFramework1.
FOUNDATION_EXPORT double DynamicFramework1VersionNumber;

//! Project version string for DynamicFramework1.
FOUNDATION_EXPORT const unsigned char DynamicFramework1VersionString[];

#import <DynamicFramework1/DF1Class1.h>
